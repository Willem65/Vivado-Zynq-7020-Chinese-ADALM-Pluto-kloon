// Top level, wraps around the block diagram as created by Vivado.
//
// Derived from AD top level design


`timescale 1ns/100ps

module system_top (

    inout   [14:0]  ddr_addr,
    inout   [ 2:0]  ddr_ba,
    inout           ddr_cas_n,
    inout           ddr_ck_n,
    inout           ddr_ck_p,
    inout           ddr_cke,
    inout           ddr_cs_n,
    inout   [ 3:0]  ddr_dm,
    inout   [31:0]  ddr_dq,
    inout   [ 3:0]  ddr_dqs_n,
    inout   [ 3:0]  ddr_dqs_p,
    inout           ddr_odt,
    inout           ddr_ras_n,
    inout           ddr_reset_n,
    inout           ddr_we_n,
    
    inout           fixed_io_ddr_vrn,
    inout           fixed_io_ddr_vrp,
    inout   [53:0]  fixed_io_mio,
    inout           fixed_io_ps_clk,
    inout           fixed_io_ps_porb,
    inout           fixed_io_ps_srstb,
    
    inout           iic_scl,
    inout           iic_sda,
    
    input           rx_clk_in_p,
    input           rx_clk_in_n,
    input           rx_frame_in_p,
    input           rx_frame_in_n,
    input   [ 5:0]  rx_data_in_p,
    input   [ 5:0]  rx_data_in_n,
    output          tx_clk_out_p,
    output          tx_clk_out_n,
    output          tx_frame_out_p,
    output          tx_frame_out_n,
    output  [ 5:0]  tx_data_out_p,
    output  [ 5:0]  tx_data_out_n,
    
    output          enable,
    output          txnrx,
    
    inout           gpio_resetb,
    inout           gpio_en_agc,
    inout   [ 3:0]  gpio_ctl,
    inout   [ 7:0]  gpio_status,
    
    output          spi_csn,
    output          spi_clk,
    output          spi_mosi,
    input           spi_miso,
    
    output          pl_spi_clk_o,
    output          pl_spi_mosi,
    input           pl_spi_miso,
    
    // Baseband connections
    //output          clk_to_bb,
    //input           clk_to_sdr,
    //input   [ 5:0]  bb_in_ddr,
    // output          gpio_bb_0,
    // output          gpio_bb_1,
    //inout           IIC_0_0_scl_io,
    //inout           IIC_0_0_sda_io,
    //output          gpio_bb_2,
    output          gpio_bb_3,
    //input           led_clk,

    input  wire clk_in1,      // 50 MHz systeemklok, pin N18
  
    // -- I2SRX testsignalen (rechtstreeks, geen switch-logica nog) --
    input  wire i2s_in_bclk,   // 
    input  wire i2s_in_lrclk,  // 
    input  wire i2s_in_data,   // 
    //input  wire i2s_reset,     // pin H17
    
    //Up_Sampler_Output
    output wire i2s_out_lrclk384,
    output wire i2s_out_data384,
    output wire i2s_out_clk384
);
    
   

    led_blinker my_led_test (
        .clk    (clk_in1),
        .led_o  (gpio_bb_3)
    );


     

    // ------------------------------------------------------------
    // Proper 10 ms power-on reset 
    // ------------------------------------------------------------
	wire i2s_reset;
	
//	assign i2s_reset = 1'b0;
	
	reset u_reset(
		.clk_master50	(clk_in1),     
		.reset_out		(i2s_reset)
	);
	
	
	    // -----------------------------------------------------------
    // clk_wiz_0: upsample-klokken (24.576 / 49.152 MHz) afgeleid
    // van de inkomende i2s_in_bclk (12.288 MHz). Exacte x2/x4
    // vermenigvuldiging, geen afronding nodig.
    // Noodklok/switch-logica bij wegvallen van i2s_in_bclk: later.
    // -----------------------------------------------------------
    wire clk2_out1;
    wire clk_49152;
    wire locked2;

//    clk_wiz_0 clk_wiz_0_inst
//    (
//        // Clock out ports
//        .clk_out1 (clk2_out1), // output clk_out1, 24.576 MHz
//        .clk_out2 (clk_49152), // output clk_out2, 49.152 MHz
//        // Status and control signals
//        .reset    (i2s_reset), // input reset, zelfde reset als I2SRX
//        .locked   (locked2),   // output locked
//        // Clock in ports
//        .clk_in1  (clk_in1) // input clk_in1, 12.288 MHz extern BCLK
//    );


       clk_wiz_i2s clk_wiz_i2s_inst
       (
           // Clock out ports  
           .clk_out1(clk2_out1),
           .clk_out2(clk_49152),
           // Status and control signals               
           .reset(i2s_reset), 
           .locked(locked2),
          // Clock in ports
           .clk_in1(i2s_in_bclk)
       );


    // ------------------------------------------------------------
    // 12b. Interpolatie 384 kHz -> 768 kHz (halfband, ter onderdrukking
    // van de 384 kHz-spiegelbeelden), vóór de fabric-DAC-koppeling.
    // ------------------------------------------------------------
    wire s_i_tready, s_q_tready;   // AXI-Stream ready-signalen, niet gebruikt (zie toelichting)
    wire m_i_valid, m_q_valid;
    wire [31:0] m_i_data32, m_q_data32;

    fir_interp_384_768_i u_interp_i (
        .aclk               (clk_49152),
        .s_axis_data_tvalid (strobe_iq),
        .s_axis_data_tready (s_i_tready),
        .s_axis_data_tdata  (I_filtered[31:16]),
        .m_axis_data_tvalid (m_i_valid),
        .m_axis_data_tdata  (m_i_data32)
    );

    fir_interp_384_768_q u_interp_q (
        .aclk               (clk_49152),
        .s_axis_data_tvalid (strobe_iq),
        .s_axis_data_tready (s_q_tready),
        .s_axis_data_tdata  (Q_filtered[31:16]),
        .m_axis_data_tvalid (m_q_valid),
        .m_axis_data_tdata  (m_q_data32)
    );

    wire signed [15:0] i0_interp = m_i_data32[31:16];
    wire signed [15:0] q0_interp = m_q_data32[31:16];


    // ------------------------------------------------------------
    // 12b. Interpolatie 768_1536 (halfband, ter onderdrukking
    // van de 1536 kHz-spiegelbeelden), vóór de fabric-DAC-koppeling.
    // ------------------------------------------------------------
    wire s_i2_tready, s_q2_tready;
    wire m_i2_valid, m_q2_valid;
    wire [31:0] m_i2_data32, m_q2_data32;

    fir_interp_768_1536_i u_interp2_i (
        .aclk               (clk_49152),
        .s_axis_data_tvalid (m_i_valid),
        .s_axis_data_tready (s_i2_tready),
        .s_axis_data_tdata  (m_i_data32[31:16]),
        .m_axis_data_tvalid (m_i2_valid),
        .m_axis_data_tdata  (m_i2_data32)
    );

    fir_interp_768_1536_q u_interp2_q (
        .aclk               (clk_49152),
        .s_axis_data_tvalid (m_q_valid),
        .s_axis_data_tready (s_q2_tready),
        .s_axis_data_tdata  (m_q_data32[31:16]),
        .m_axis_data_tvalid (m_q2_valid),
        .m_axis_data_tdata  (m_q2_data32)
    );

    wire signed [15:0] i0_interp2 = m_i2_data32[31:16];
    wire signed [15:0] q0_interp2 = m_q2_data32[31:16];




    // -----------------------------------------------------------
    // I2SRX testopstelling: rechtstreeks extern BCLK/LRCLK/DATA,
    // nog geen switch-logica naar interne fallback-klokken.
    // -----------------------------------------------------------
    wire i2s_rx_strobe;
    wire [31:0] rx_sample;
    
    I2SRX i2s_ingang
    (
        .i2s_in_bclk    (i2s_in_bclk),
        .reset          (i2s_reset),
        .i2s_in_lrclk   (i2s_in_lrclk),
        .i2s_in_data    (i2s_in_data),

        .i2s_rx_strobe  (i2s_rx_strobe),
        .rx_sample      (rx_sample)
    );



    // ------------------------------------------------------------    
    // 6. Upsampler (192 kHz -> 384 kHz)
    // ------------------------------------------------------------
    wire [31:0] up_sample;     
    wire strobe_384;           

    Upsampler u_Upsampler(
        .clk_49152  (clk_49152),
        .reset      (i2s_reset),
        .sample_in  (rx_sample),
        .strobe_192 (i2s_rx_strobe),
        
        .sample_out (up_sample),
        .strobe_384 (strobe_384)
    );            

    
    
    // ------------------------------------------------------------
    // 7. FIR Filter (Na Upsampler)
    // ------------------------------------------------------------
    wire [31:0] filtered_sample; 
    wire strobe_filtered;

    FIR_Filter u_FIR (
        .clk_49152  (clk_49152), 
        .reset      (i2s_reset),
        .sample_in  (up_sample),    
        .strobe_in  (strobe_384),   
        .bypass     (1'b0),        // 1 = Filter UIT, 0 = Filter AAN
        
        .sample_out (filtered_sample),
        .strobe_out (strobe_filtered)
    );    
         


    
    // ------------------------------------------------------------
    // 8. Phase accumulator
    // ------------------------------------------------------------    
    //wire [10:0] phase_w; 
	wire [15:0] phase_w;
	wire test_signal;
        
    PHASEACCUMULATOR phase_acc(    
         .sample_in      (filtered_sample[31-:16]), 
         //.test_signal    (test_signal),
		 .test_signal    (1'b0),   //   Dit heeft geen enkele invloed meer, kijk maar in de phaseaccumulator functie 
         .tone_offset    (tone_offset_fab_tri_o),   // nieuw
         .reset          (i2s_reset),
         .clk_49152      (clk_49152),
         .strobe_in      (strobe_filtered),
        
         .strobe_out     (strobe_w2),
         .phase_out      (phase_w)
    ); 

    
    // ------------------------------------------------------------
    // 9. Phase -> IQ met de nieuwe Integrated Quarter-wave LUT 90 degrees 
    // ------------------------------------------------------------    
    wire signed [31:0] I16;
    wire signed [31:0] Q16;
    
    //wire signed [31:0] I_data = I16;
    //wire signed [31:0] Q_data = Q16; 

    wire [15:0] tone_offset_fab_tri_o;
    wire [15:0] phase_fab_tri_o;
    wire [15:0] gain_i_fab_tri_o;
    wire [15:0] gain_q_fab_tri_o;
    wire [15:0] dc_i_fab_tri_o;
    wire [15:0] dc_q_fab_tri_o;
    // ------------------------------------------------------------
    // IQ-correctie: DC-offset, gain, fase — instelbaar via GPIO-registers NIEUW
    // ------------------------------------------------------------
    wire signed [15:0] dc_i    = dc_i_fab_tri_o;
    wire signed [15:0] dc_q    = dc_q_fab_tri_o;
    wire signed [15:0] gain_i  = gain_i_fab_tri_o;   // fixed-point, 0x4000 = 1.0 (Q2.14)
    wire signed [15:0] gain_q  = gain_q_fab_tri_o;
    wire signed [15:0] phase_c = phase_fab_tri_o;    // fixed-point, sin(fase), Q2.14

    // Stap 1: gain toepassen (Q2.14 fixed-point vermenigvuldiging)
    wire signed [47:0] i_gained_full = I16 * gain_i;
    wire signed [47:0] q_gained_full = Q16 * gain_q;
    wire signed [31:0] i_gained = i_gained_full[45:14];
    wire signed [31:0] q_gained = q_gained_full[45:14];

    // Stap 2: fasecorrectie (Q_correct = Q - sin(fase)*I), Q2.14 fixed-point
    wire signed [47:0] phase_corr_full = i_gained * phase_c;
    wire signed [31:0] phase_corr = phase_corr_full[45:14];
    wire signed [31:0] q_phase_corrected = q_gained - phase_corr;

    // Stap 3: DC-offset optellen
    wire signed [31:0] I_data = i_gained         + {{16{dc_i[15]}}, dc_i};
    wire signed [31:0] Q_data = q_phase_corrected + {{16{dc_q[15]}}, dc_q};




    wire [9:0] phase_adj;    
    
    wire iq_valid_new;

    LUT90 u_LUT90 (
        .clk         (clk_49152),
        .rst         (i2s_reset),
        .ce_fs       (strobe_w2),
        .phase       (phase_w),
		.phase_adj   (16'd1),
        .I           (I16),
        .Q           (Q16),
        .iq_valid    (iq_valid_new)
    );   
    

    
    // ============================================================
    // 10. DE WACHTKAMER OPLOSSING (Perfecte I2S Frame Uitlijning)
    // ============================================================
    wire [31:0] I_filtered;
    wire [31:0] Q_filtered;
    wire        strobe_iq; 
    wire    dac_clk_fab;

    FIR_IQ filter_i (
        .clk_49152 (clk_49152),
        .reset     (i2s_reset),
        .sample_in (I_data),      
        .strobe_in (iq_valid_new),   
        .sample_out(I_filtered),
        .strobe_out(strobe_iq)    
    );

    FIR_IQ filter_q (
        .clk_49152 (clk_49152),
        .reset     (i2s_reset),
        .sample_in (Q_data),      
        .strobe_in (iq_valid_new),   
        .sample_out(Q_filtered),
        .strobe_out()             
    );  



    // ------------------------------------------------------------
    // 12. Fabric-direct AD9361 DAC-kanaal 0: klokdomein-synchronizer
    // ------------------------------------------------------------
    reg signed [15:0] i0_sync_1, i0_sync_2;
    reg signed [15:0] q0_sync_1, q0_sync_2;

    always @(posedge dac_clk_fab) begin
        // i0_sync_1 <= I_filtered[31:16];
        // i0_sync_2 <= i0_sync_1;
        // q0_sync_1 <= Q_filtered[31:16];
        // q0_sync_2 <= q0_sync_1;
        // i0_sync_1 <= i0_interp;      // was: I_filtered[31:16]
        // i0_sync_2 <= i0_sync_1;
        // q0_sync_1 <= q0_interp;      // was: Q_filtered[31:16]
        // q0_sync_2 <= q0_sync_1;  
        i0_sync_1 <= i0_interp2;      // was: i0_interp
        i0_sync_2 <= i0_sync_1;
        q0_sync_1 <= q0_interp2;      // was: q0_interp
        q0_sync_2 <= q0_sync_1;      
    end
    
      

    // Puls Oprekker 
    reg strobe_w2_delay;
    always @(posedge clk_49152) begin
        strobe_w2_delay <= strobe_w2;
    end
    
    wire safe_tx_strobe = strobe_w2 | strobe_w2_delay;  
    
    
    // ------------------------------------------------------------
    // 11. I2S uitgang
    // ------------------------------------------------------------           
    I2STX i2s_uitgang(
        .i2s_tx_bclk    (clk2_out1),              
        .reset          (i2s_reset),        
        .tx_in_left     (I_filtered), 
        .tx_in_right    (Q_filtered),         
        .tx_strobe      (safe_tx_strobe), 
		
        .i2s_tx_lrclk   (i2s_out_lrclk384),
        .i2s_out_data   (i2s_out_data384)
    );      
    
    
    //assign i2s_out_data384 = i2s_out_data384;
    //assign i2s_out_lrclk384 = i2s_out_lrclk;  
    assign i2s_out_clk384 = clk2_out1;   







































  // internal signals

  wire    [17:0]  gpio_i;
  wire    [17:0]  gpio_o;
  wire    [17:0]  gpio_t;

  // instantiations

  ad_iobuf #(
    .DATA_WIDTH(14)
  ) i_iobuf (
    .dio_t (gpio_t[13:0]),
    .dio_i (gpio_o[13:0]),
    .dio_o (gpio_i[13:0]),
    .dio_p ({ gpio_resetb,        // 13:13
              gpio_en_agc,        // 12:12
              gpio_ctl,           // 11: 8
              gpio_status}));     //  7: 0

  assign gpio_i[16:14] = gpio_o[16:14];

  system_wrapper i_system_wrapper (
    //.IIC_0_0_scl_io (IIC_0_0_scl_io),
    //.IIC_0_0_sda_io (IIC_0_0_sda_io),
    //bb_in_ddr (bb_in_ddr),
    //.clk_to_bb (clk_to_bb),
    //.clk_to_sdr (clk_to_sdr),
    // .gpio_bb_0 (gpio_bb_0),
    // .gpio_bb_1 (gpio_bb_1),
    //.gpio_bb_2 (gpio_bb_2),
    //.gpio_bb_2 (0),
    //.gpio_bb_3 (gpio_bb_3),
    
    
    
    
    //.IIC_0_0_scl_io (0),
    //.IIC_0_0_sda_io (0),
    //.bb_in_ddr (0),
    //.clk_to_bb (0),
    //.clk_to_sdr (clk_in1),
    //.gpio_bb_0 (0),
    //.gpio_bb_1 (0),
    //.gpio_bb_2 (0),
    //.gpio_bb_2 (0),
    //.gpio_bb_3 (0),

    .tone_offset_fab_tri_o (tone_offset_fab_tri_o),
    .phase_fab_tri_o       (phase_fab_tri_o),
    .gain_i_fab_tri_o      (gain_i_fab_tri_o),
    .gain_q_fab_tri_o      (gain_q_fab_tri_o),
    .dc_i_fab_tri_o        (dc_i_fab_tri_o),
    .dc_q_fab_tri_o        (dc_q_fab_tri_o),
    
    
    .ddr_addr (ddr_addr),
    .ddr_ba (ddr_ba),
    .ddr_cas_n (ddr_cas_n),
    .ddr_ck_n (ddr_ck_n),
    .ddr_ck_p (ddr_ck_p),
    .ddr_cke (ddr_cke),
    .ddr_cs_n (ddr_cs_n),
    .ddr_dm (ddr_dm),
    .ddr_dq (ddr_dq),
    .ddr_dqs_n (ddr_dqs_n),
    .ddr_dqs_p (ddr_dqs_p),
    .ddr_odt (ddr_odt),
    .ddr_ras_n (ddr_ras_n),
    .ddr_reset_n (ddr_reset_n),
    .ddr_we_n (ddr_we_n),
    .enable (enable),
    .fixed_io_ddr_vrn (fixed_io_ddr_vrn),
    .fixed_io_ddr_vrp (fixed_io_ddr_vrp),
    .fixed_io_mio (fixed_io_mio),
    .fixed_io_ps_clk (fixed_io_ps_clk),
    .fixed_io_ps_porb (fixed_io_ps_porb),
    .fixed_io_ps_srstb (fixed_io_ps_srstb),
    .gpio_i (gpio_i),
    .gpio_o (gpio_o),
    .gpio_t (gpio_t),
    .iic_main_scl_io (iic_scl),
    .iic_main_sda_io (iic_sda),
    .rx_clk_in_p (rx_clk_in_p),
    .rx_clk_in_n (rx_clk_in_n),
    .rx_data_in_p (rx_data_in_p),
    .rx_data_in_n (rx_data_in_n),
    .rx_frame_in_p (rx_frame_in_p),
    .rx_frame_in_n (rx_frame_in_n),

    .spi0_clk_i (1'b0),
    .spi0_clk_o (spi_clk),
    .spi0_csn_0_o (spi_csn),
    .spi0_csn_1_o (),
    .spi0_csn_2_o (),
    .spi0_csn_i (1'b1),
    .spi0_sdi_i (spi_miso),
    .spi0_sdo_i (1'b0),
    .spi0_sdo_o (spi_mosi),

    .spi_clk_i(1'b0),
    .spi_clk_o(pl_spi_clk_o),
    .spi_csn_i(1'b1),
    .spi_csn_o(),
    .spi_sdi_i(pl_spi_miso),
    .spi_sdo_i(1'b0),
    .spi_sdo_o(pl_spi_mosi),

    .tx_clk_out_p (tx_clk_out_p),
    .tx_clk_out_n (tx_clk_out_n),
    .tx_data_out_p (tx_data_out_p),
    .tx_data_out_n (tx_data_out_n),

    //.dac_data_i0_fab (16'sd0),
    //.dac_data_q0_fab (16'sd0),

    .dac_data_i0_fab (i0_sync_2),
    .dac_data_q0_fab (q0_sync_2),
    .dac_clk_fab (dac_clk_fab),

    .tx_frame_out_p (tx_frame_out_p),
    .tx_frame_out_n (tx_frame_out_n),
    .txnrx (txnrx),
    .up_enable (gpio_o[15]),
    .up_txnrx (gpio_o[16]));

endmodule
