`timescale 1ns / 1ps

module PHASEACCUMULATOR (
       input  signed [15:0]     sample_in,   // modulatie amplitude
       input                    reset,
       input                    clk_49152,   // ALTIJD de snelle klok!
       input                    strobe_in,
       input                    test_signal, // Arduino
       input signed [15:0]      tone_offset,   // nieuwe poort
    
       output reg               strobe_out,
       output reg [PHASE_WIDTH-1:0] phase_out // Slaat automatisch op de juiste breedte
   );

   // ============================================================
   // INSTELLINGEN (Nu als localparam, veilig vastgezet in deze module)
   // ============================================================
	localparam PHASE_WIDTH = 16; // voor een kwart sinus 90 graden is het 4 keer 16384 dus 16
	
   //localparam PHASE_WIDTH = 14; // 14 = 16384 punten tabel  //
                                // 12 = 4096 punten tabel
                                // 11 = 2048 punten tabel  //
								 // 8 = 256 punten
								 // 6 = 64  punten
								 // 5 = 32
								 // 4 = 16
                                
   localparam signed [17:0] K_FM = 18'sd65535;  

   // ============================================================
   // Registers
   // ============================================================
   //reg signed [31:0] fm_prod;
   reg signed [31:0] phase_acc;
   reg signed [15:0] sample;

   // ============================================================
   // Phase accumulator logica
   // ============================================================
   always @(posedge clk_49152) begin
       if (reset) begin
           phase_acc  <= 32'sd0;
           strobe_out <= 1'b0; 
           sample     <= 16'sd0;
           phase_out  <= 0; // Reset naar 0, ongeacht de breedte
       end else begin
           strobe_out <= 1'b0;
            
           if (strobe_in) begin
               strobe_out <= 1'b1;

            //    // Kies bron (Test of I2S Audio)
            //    if (test_signal == 1'b1) begin
            //        //sample = 16'sd10000;
            //        sample <= tone_offset;          // was: sample <= 16'sd10000;
            //    end else begin
            //        sample = sample_in;
            //    end    


                if (tone_offset != 16'sd0) begin
                    sample <= tone_offset;
                end else begin
                    sample = sample_in;
                end



               
               phase_acc <= phase_acc + ($signed(sample) * K_FM);

               // De Magische Formule: Pak automatisch de juiste bovenste bits!
               phase_out <= phase_acc[31 : 32 - PHASE_WIDTH]; 
           end
       end
   end
endmodule

