

# bb_in_ddr[0]	G20	LVCMOS25	EXT IO Pin
# bb_in_ddr[1]	J18	LVCMOS25	EXT IO Pin
# bb_in_ddr[2]	H18	LVCMOS25	EXT IO Pin
# bb_in_ddr[3]	H17	LVCMOS25	EXT IO Pin
# bb_in_ddr[4]	L14	LVCMOS25	De meest zekere GPIO pin!
# bb_in_ddr[5]	L15	LVCMOS25	EXT IO Pin


# Externe Klok op pin N18 (Bank 34)
#set_property PACKAGE_PIN N18 [get_ports led_clk]
#set_property IOSTANDARD LVCMOS25 [get_ports led_clk]
#create_clock -add -name sys_clk_pin -period 25.00 -waveform {0 12.5} [get_ports led_clk]


# Systeemklok input, 50 MHz (was: led_clk / sys_clk_pin)
set_property PACKAGE_PIN N18 [get_ports clk_in1]
set_property IOSTANDARD LVCMOS25 [get_ports clk_in1]
create_clock -period 25.000 -name sys_clk_pin -waveform {0.000 12.500} -add [get_ports clk_in1]

# LED op pin V10 (Bank 35)
#set_property PACKAGE_PIN U10 [get_ports led_o]
#set_property IOSTANDARD LVCMOS33 [get_ports led_o]




# constraints
# ad9361 (SWAP == 0x1)

set_property -dict {PACKAGE_PIN U18 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports rx_clk_in_p]
set_property -dict {PACKAGE_PIN U19 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports rx_clk_in_n]
set_property -dict {PACKAGE_PIN Y16 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports rx_frame_in_p]
set_property -dict {PACKAGE_PIN Y17 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports rx_frame_in_n]
set_property -dict {PACKAGE_PIN Y18 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[0]}]
set_property -dict {PACKAGE_PIN Y19 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[0]}]
set_property -dict {PACKAGE_PIN T16 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[1]}]
set_property -dict {PACKAGE_PIN U17 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[1]}]
set_property -dict {PACKAGE_PIN V20 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[2]}]
set_property -dict {PACKAGE_PIN W20 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[2]}]
set_property -dict {PACKAGE_PIN T17 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[3]}]
set_property -dict {PACKAGE_PIN R18 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[3]}]
set_property -dict {PACKAGE_PIN T20 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[4]}]
set_property -dict {PACKAGE_PIN U20 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[4]}]
set_property -dict {PACKAGE_PIN W18 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_p[5]}]
set_property -dict {PACKAGE_PIN W19 IOSTANDARD LVDS_25 DIFF_TERM 1} [get_ports {rx_data_in_n[5]}]
set_property -dict {PACKAGE_PIN U14 IOSTANDARD LVDS_25} [get_ports tx_clk_out_p]
set_property -dict {PACKAGE_PIN U15 IOSTANDARD LVDS_25} [get_ports tx_clk_out_n]
set_property -dict {PACKAGE_PIN V16 IOSTANDARD LVDS_25} [get_ports tx_frame_out_p]
set_property -dict {PACKAGE_PIN W16 IOSTANDARD LVDS_25} [get_ports tx_frame_out_n]
set_property -dict {PACKAGE_PIN V15 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[0]}]
set_property -dict {PACKAGE_PIN W15 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[0]}]
set_property -dict {PACKAGE_PIN V12 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[1]}]
set_property -dict {PACKAGE_PIN W13 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[1]}]
set_property -dict {PACKAGE_PIN W14 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[2]}]
set_property -dict {PACKAGE_PIN Y14 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[2]}]
set_property -dict {PACKAGE_PIN T12 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[3]}]
set_property -dict {PACKAGE_PIN U12 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[3]}]
set_property -dict {PACKAGE_PIN T11 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[4]}]
set_property -dict {PACKAGE_PIN T10 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[4]}]
set_property -dict {PACKAGE_PIN U13 IOSTANDARD LVDS_25} [get_ports {tx_data_out_p[5]}]
set_property -dict {PACKAGE_PIN V13 IOSTANDARD LVDS_25} [get_ports {tx_data_out_n[5]}]

set_property -dict {PACKAGE_PIN L20 IOSTANDARD LVCMOS25} [get_ports {gpio_status[0]}]
set_property -dict {PACKAGE_PIN L19 IOSTANDARD LVCMOS25} [get_ports {gpio_status[1]}]
set_property -dict {PACKAGE_PIN K19 IOSTANDARD LVCMOS25} [get_ports {gpio_status[2]}]
set_property -dict {PACKAGE_PIN T14 IOSTANDARD LVCMOS25} [get_ports {gpio_status[3]}]
set_property -dict {PACKAGE_PIN P15 IOSTANDARD LVCMOS25} [get_ports {gpio_status[4]}]
set_property -dict {PACKAGE_PIN M20 IOSTANDARD LVCMOS25} [get_ports {gpio_status[5]}]
set_property -dict {PACKAGE_PIN M19 IOSTANDARD LVCMOS25} [get_ports {gpio_status[6]}]
set_property -dict {PACKAGE_PIN N20 IOSTANDARD LVCMOS25} [get_ports {gpio_status[7]}]

set_property -dict {PACKAGE_PIN J19 IOSTANDARD LVCMOS25} [get_ports {gpio_ctl[0]}]
set_property -dict {PACKAGE_PIN K14 IOSTANDARD LVCMOS25} [get_ports {gpio_ctl[1]}]
set_property -dict {PACKAGE_PIN L17 IOSTANDARD LVCMOS25} [get_ports {gpio_ctl[2]}]
set_property -dict {PACKAGE_PIN J20 IOSTANDARD LVCMOS25} [get_ports {gpio_ctl[3]}]
set_property -dict {PACKAGE_PIN P20 IOSTANDARD LVCMOS25} [get_ports gpio_en_agc]
set_property -dict {PACKAGE_PIN R19 IOSTANDARD LVCMOS25} [get_ports gpio_resetb]

set_property -dict {PACKAGE_PIN T15 IOSTANDARD LVCMOS25} [get_ports enable]
set_property -dict {PACKAGE_PIN P18 IOSTANDARD LVCMOS25} [get_ports txnrx]

set_property PACKAGE_PIN M14 [get_ports iic_scl]
set_property IOSTANDARD LVCMOS25 [get_ports iic_scl]
set_property PULLUP true [get_ports iic_scl]
set_property PACKAGE_PIN M15 [get_ports iic_sda]
set_property IOSTANDARD LVCMOS25 [get_ports iic_sda]
set_property PULLUP true [get_ports iic_sda]

set_property PACKAGE_PIN R17 [get_ports spi_csn]
set_property IOSTANDARD LVCMOS25 [get_ports spi_csn]
set_property PULLUP true [get_ports spi_csn]
set_property -dict {PACKAGE_PIN V18 IOSTANDARD LVCMOS25} [get_ports spi_clk]
set_property -dict {PACKAGE_PIN P16 IOSTANDARD LVCMOS25} [get_ports spi_mosi]
set_property -dict {PACKAGE_PIN V17 IOSTANDARD LVCMOS25} [get_ports spi_miso]

# NB!
# The original Fishball HDL design has an ADI SPI core, connected to the pins below.
# However, the pins are not connected to something on the PCB (apparently).
# However, on the Fishball-with-GPIO, the L14 pin is connected to the GPIO connector.
# I don't date to remove the SPI core now, so I connected the pl_spi_clk_o to an
# unused FPGA pin.
# TODO: remove the ADI SPI core and from the BSP, if applicable.

# set_property -dict {PACKAGE_PIN L14 IOSTANDARD LVCMOS25} [get_ports pl_spi_clk_o]
set_property -dict {PACKAGE_PIN J14 IOSTANDARD LVCMOS25} [get_ports pl_spi_clk_o]
set_property -dict {PACKAGE_PIN N15 IOSTANDARD LVCMOS25} [get_ports pl_spi_miso]
set_property -dict {PACKAGE_PIN N16 IOSTANDARD LVCMOS25} [get_ports pl_spi_mosi]


create_clock -period 4.000 -name rx_clk [get_ports rx_clk_in_p]

# probably gone in 2016.4

create_clock -period 10.000 -name clk_fpga_0 [get_pins {i_system_wrapper/system_i/sys_ps7/inst/PS7_i/FCLKCLK[0]}]
create_clock -period 5.000 -name clk_fpga_1 [get_pins {i_system_wrapper/system_i/sys_ps7/inst/PS7_i/FCLKCLK[1]}]

create_clock -period 40.000 -name spi0_clk [get_pins -hier */EMIOSPI0SCLKO]

set_input_jitter clk_fpga_0 0.300
set_input_jitter clk_fpga_1 0.150

# Baseband interface pins Header 20

#set_property -dict {PACKAGE_PIN G19 IOSTANDARD LVCMOS25} [get_ports clk_to_bb]
#set_property -dict {PACKAGE_PIN H16 IOSTANDARD LVCMOS25} [get_ports clk_to_sdr]
#set_property -dict {PACKAGE_PIN G20 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[0]}]
#set_property -dict {PACKAGE_PIN J18 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[1]}]
#set_property -dict {PACKAGE_PIN H18 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[2]}]
#set_property -dict {PACKAGE_PIN H17 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[3]}]   #deze
#set_property -dict {PACKAGE_PIN L14 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[4]}]   #deze
#set_property -dict {PACKAGE_PIN L15 IOSTANDARD LVCMOS25} [get_ports {bb_in_ddr[5]}]   #deze

#set_property -dict {PACKAGE_PIN V10 IOSTANDARD LVCMOS33} [get_ports IIC_0_0_scl_io]   #deze
#set_property -dict {PACKAGE_PIN U9 IOSTANDARD LVCMOS33} [get_ports IIC_0_0_sda_io]    #deze
#set_property PULLTYPE PULLUP [get_ports IIC_0_0_scl_io]
#set_property PULLTYPE PULLUP [get_ports IIC_0_0_sda_io]
#set_property -dict {PACKAGE_PIN U10 IOSTANDARD LVCMOS33} [get_ports gpio_bb_2]        #deze
set_property -dict {PACKAGE_PIN T9 IOSTANDARD LVCMOS33} [get_ports gpio_bb_3]


# i2s_in_bclk (was: bb_in_ddr[0])
set_property PACKAGE_PIN L15 [get_ports i2s_in_bclk]
set_property IOSTANDARD LVCMOS25 [get_ports i2s_in_bclk]
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets i2s_in_bclk_IBUF]
# i2s_in_lrclk (was: bb_in_ddr[1])
set_property PACKAGE_PIN L14 [get_ports i2s_in_lrclk]
set_property IOSTANDARD LVCMOS25 [get_ports i2s_in_lrclk]
# i2s_in_data (was: bb_in_ddr[2])
set_property PACKAGE_PIN H17 [get_ports i2s_in_data]
set_property IOSTANDARD LVCMOS25 [get_ports i2s_in_data]
# i2s_in_bclk is een los, asynchroon extern klokdomein t.o.v. clk_in1 -> declareren
create_clock -period 81.380 -name i2s_bclk_pin -add [get_ports i2s_in_bclk]
set_clock_groups -asynchronous -group [get_clocks sys_clk_pin] -group [get_clocks i2s_bclk_pin]



# i2s_out 384
set_property PACKAGE_PIN V10 [get_ports i2s_out_lrclk384]
set_property IOSTANDARD LVCMOS33 [get_ports i2s_out_lrclk384]
set_property PACKAGE_PIN U9 [get_ports i2s_out_data384]
set_property IOSTANDARD LVCMOS33 [get_ports i2s_out_data384]
# # Test-output 2: 24.576 MHz (was: clk_to_sdr)
set_property PACKAGE_PIN U10 [get_ports i2s_out_clk384]
set_property IOSTANDARD LVCMOS33 [get_ports i2s_out_clk384]









# Timing constraints

set_property BITSTREAM.GENERAL.COMPRESS TRUE [current_design]
set_false_path -from [get_pins {i_system_wrapper/system_i/axi_bb_input_0/U0/read_errors_reg[*]/C}] -to [get_pins {i_system_wrapper/system_i/axi_bb_input_0/U0/axi_interface/axi_rdata_reg[*]/D}]
set_false_path -from [get_pins {i_system_wrapper/system_i/axi_bb_input_0/U0/write_errors_reg[*]/C}] -to [get_pins {i_system_wrapper/system_i/axi_bb_input_0/U0/axi_interface/axi_rdata_reg[*]/D}]

#create_clock -period 20.200 -name clk_to_sdr -waveform {0.000 10.100} [get_ports clk_to_sdr]

# Source-synchronous DDR, center-aligned clock (clock edge in center of data eye).
# Data is stable from 3 ns (min) to 7 ns (max) after each clock edge.
# IMPORTANT: set_input_delay without -add_delay REPLACES all existing constraints for
# that port/clock combination. Only the first constraint may omit -add_delay;
# every subsequent one must use -add_delay to accumulate alongside it.
#set_input_delay -clock [get_clocks clk_to_sdr] -max             7.0            [get_ports {bb_in_ddr[*]}]
#set_input_delay -clock [get_clocks clk_to_sdr] -min             3.0 -add_delay [get_ports {bb_in_ddr[*]}]
#set_input_delay -clock [get_clocks clk_to_sdr] -max -clock_fall 7.0 -add_delay [get_ports {bb_in_ddr[*]}]
#set_input_delay -clock [get_clocks clk_to_sdr] -min -clock_fall 3.0 -add_delay [get_ports {bb_in_ddr[*]}]


set_clock_groups -asynchronous -group [get_clocks sys_clk_pin] -group [get_clocks -include_generated_clocks {clk_out1_clk_wiz_i2s clk_out2_clk_wiz_i2s}]

set_clock_groups -asynchronous -group [get_clocks -include_generated_clocks {clk_out1_clk_wiz_i2s clk_out2_clk_wiz_i2s}] -group [get_clocks rx_clk]

#set_clock_groups -asynchronous -group [get_clocks -include_generated_clocks {clk_out1_clk_wiz_i2s clk_out2_clk_wiz_i2s}] -group [get_clocks {rx_clk clk_fpga_0}]

set_clock_groups -asynchronous -group [get_clocks -include_generated_clocks {clk_out1_clk_wiz_i2s clk_out2_clk_wiz_i2s}] -group [get_clocks clk_fpga_0]

set_false_path -from [get_cells {i_system_wrapper/system_i/axi_ad9361/inst/i_tx/i_up_dac_common/up_dac_gpio_out_int_reg[*]}] -to [get_cells {i_system_wrapper/system_i/tx_fir_interpolator/cdc_sync_active/inst/cdc_sync_stage1_reg[*]}]

set_false_path -from [get_cells i_system_wrapper/system_i/axi_ad9361_dac_dma/inst/i_transfer/i_request_arb/i_store_and_forward/i_mem/m_ram_reg] -to [get_cells {i_system_wrapper/system_i/tx_upack/inst/i_upack/fifo_rd_data_reg[*]}]



