source ../../scripts/adi_env.tcl
source $ad_hdl_dir/projects/scripts/adi_project_xilinx.tcl
source $ad_hdl_dir/projects/scripts/adi_board.tcl

adi_project_create pluto 0 {} "xc7z020clg400-2"

adi_project_files pluto [list \
  "system_top.v" \
  "led_blinker.v" \
  "reset.v" \
  "I2SRX.v" \
  "Upsampler.v" \
  "FIR_Filter.v" \
  "PHASEACCUMULATOR.v" \
  "LUT90.v" \
  "FIR_IQ.v" \
  "I2STX.v" \
  "sin_qtr2.mem" \
  "clk_wiz_i2s.xci" \
  "fir_interp_384_768_i.xci" \
  "fir_interp_384_768_q.xci" \
  "fir_interp_768_1536_i.xci" \
  "fir_interp_768_1536_q.xci" \
  "system_constr.xdc" \
  "$ad_hdl_dir/library/util_cdc/sync_bits.v" \
  "$ad_hdl_dir/library/common/util_pulse_gen.v" \
  "$ad_hdl_dir/library/common/ad_bus_mux.v" \
  "$ad_hdl_dir/library/common/ad_iobuf.v"]

set_property is_enabled false [get_files  *system_sys_ps7_0.xdc]
adi_project_run pluto
source $ad_hdl_dir/library/axi_ad9361/axi_ad9361_delay.tcl

