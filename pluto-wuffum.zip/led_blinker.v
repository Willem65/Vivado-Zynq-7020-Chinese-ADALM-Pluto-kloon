module led_blinker(
    input clk,
    output led_o
);
    reg [22:0] counter;
    always @(posedge clk) begin
        counter <= counter + 1;
    end
    assign led_o = counter[22];
    
    
endmodule