`timescale 1ns / 1ps

module reset(

    input  wire        clk_master50,     
    output reg        reset_out

    );
	
	reg [19:0] reset_cnt = 0;  // enough for 10ms at 50MHz
	
	always @(posedge clk_master50) begin
        if (reset_cnt < 20'd1000) begin
            reset_cnt   <= reset_cnt + 1;
            reset_out <= 1'b1;   // hold DAC in reset
        end else begin
            reset_out <= 1'b0;   // release DAC
        end
    end


endmodule

