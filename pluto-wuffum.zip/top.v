`timescale 1ns / 1ps

// Top-level testmodule voor klokgeneratie op de (Chinese) ADALM-Pluto / Zynq-7020
// Doel: 50 MHz systeemklok (pin N18) omzetten naar 12.288 / 24.576 / 49.152 MHz
// via de Clocking Wizard IP (clk_wiz_0), en deze naar buiten brengen op vrije
// pins van de (ongebruikte) baseband-header, zodat ze met een scoop/logic
// analyzer te meten zijn.

module top
    (
        input  wire clk_in1,      // 50 MHz systeemklok, pin N18
        
        // -- I2SRX testsignalen (rechtstreeks, geen switch-logica nog) --
        input  wire i2s_in_bclk,   // 
        input  wire i2s_in_lrclk,  // 
        input  wire i2s_in_data,   // 
        //input  wire i2s_reset,     // pin H17
        
        //Up_Sampler_Output
        output wire i2s_out_lrclk384,
        output wire i2s_out_data384,
        output wire i2s_out_clk384
        
        //output wire vcco_test_13_1 // pin T9,  bank 13      
    );
    
   //assign i2s_reset = 1'b0; 
   
   
       // ------------------------------------------------------------
    // Proper 10 ms power-on reset 
    // ------------------------------------------------------------
	wire i2s_reset;
	
	reset u_reset(
		.clk_master50	(clk_in1),     
		.reset_out		(i2s_reset)
	);

  // wire clk_out1;
   wire clk_out2;
   wire clk_out3;
   wire locked;

    // Geen externe reset-bron beschikbaar voor deze test -> nooit resetten.
    // (Als je later een knop/GPIO als reset wilt gebruiken, vervang dit door
    // een top-level input poort.)
    wire reset = 1'b0;

    clk_wiz_0 clk_wiz_0_inst
        (
            // Clock out ports
            .clk_out1 (), // output clk_out1
            .clk_out2 (), // output clk_out2
            .clk_out3 (clk_out3), // output clk_out3
            // Status and control signals
            .reset    (reset),    // input reset
            .locked   (locked),   // output locked
            // Clock in ports
            .clk_in1  (clk_in1)   // input clk_in1
        );
    
    // -----------------------------------------------------------
    // I2SRX testopstelling: rechtstreeks extern BCLK/LRCLK/DATA,
    // nog geen switch-logica naar interne fallback-klokken.
    // -----------------------------------------------------------
    wire i2s_rx_strobe;
    wire [31:0] rx_sample;

    I2SRX i2s_ingang
        (
            .i2s_in_bclk    (i2s_in_bclk),
            .reset          (i2s_reset),
            .i2s_in_lrclk   (i2s_in_lrclk),
            .i2s_in_data    (i2s_in_data),

            .i2s_rx_strobe  (i2s_rx_strobe),
            .rx_sample      (rx_sample)
        );
    
    // -----------------------------------------------------------
    // clk_wiz_1: upsample-klokken (24.576 / 49.152 MHz) afgeleid
    // van de inkomende i2s_in_bclk (12.288 MHz). Exacte x2/x4
    // vermenigvuldiging, geen afronding nodig.
    // Noodklok/switch-logica bij wegvallen van i2s_in_bclk: later.
    // -----------------------------------------------------------
    wire clk2_out1;
    wire clk_49152;
    wire locked2;

    clk_wiz_1 clk_wiz_1_inst
        (
            // Clock out ports
            .clk_out1 (clk2_out1), // output clk_out1, 24.576 MHz
            .clk_out2 (clk_49152), // output clk_out2, 49.152 MHz
            // Status and control signals
            .reset    (i2s_reset), // input reset, zelfde reset als I2SRX
            .locked   (locked2),   // output locked
            // Clock in ports
            .clk_in1  (i2s_in_bclk) // input clk_in1, 12.288 MHz extern BCLK
        );
        
    // ------------------------------------------------------------    
    // 6. Upsampler (192 kHz -> 384 kHz)
    // ------------------------------------------------------------
    wire [31:0] up_sample;     
    wire strobe_384;           

    Upsampler u_Upsampler(
        .clk_49152  (clk_49152),
        .reset      (i2s_reset),
        .sample_in  (rx_sample),
        .strobe_192 (i2s_rx_strobe),
        
        .sample_out (up_sample),
        .strobe_384 (strobe_384)
    );            

    
    
    // ------------------------------------------------------------
    // 7. FIR Filter (Na Upsampler)
    // ------------------------------------------------------------
    wire [31:0] filtered_sample; 
    wire strobe_filtered;

    FIR_Filter u_FIR (
        .clk_49152  (clk_49152), 
        .reset      (i2s_reset),
        .sample_in  (up_sample),    
        .strobe_in  (strobe_384),   
        .bypass     (1'b0),        // 1 = Filter UIT, 0 = Filter AAN
        
        .sample_out (filtered_sample),
        .strobe_out (strobe_filtered)
    );    
         


    
    // ------------------------------------------------------------
    // 8. Phase accumulator
    // ------------------------------------------------------------    
    //wire [10:0] phase_w; 
	wire [15:0] phase_w;
	wire test_signal;
        
    PHASEACCUMULATOR phase_acc(    
         .sample_in      (filtered_sample[31-:16]), 
         //.test_signal    (test_signal),
		 .test_signal    (1'b0),
         .reset          (i2s_reset),
         .clk_49152      (clk_49152),
         .strobe_in      (strobe_filtered),
        
         .strobe_out     (strobe_w2),
         .phase_out      (phase_w)
    );    
    

    
    // ------------------------------------------------------------
    // 9. Phase -> IQ met de nieuwe Integrated Quarter-wave LUT 90 degrees 
    // ------------------------------------------------------------    
    wire signed [31:0] I16;
    wire signed [31:0] Q16;
    
    wire signed [31:0] I_data = I16;
    wire signed [31:0] Q_data = Q16;    
    wire [9:0] phase_adj;    
    
    wire iq_valid_new;

    LUT90 u_LUT90 (
        .clk         (clk_49152),
        .rst         (i2s_reset),
        .ce_fs       (strobe_w2),
        .phase       (phase_w),
		.phase_adj   (16'd1),
        .I           (I16),
        .Q           (Q16),
        .iq_valid    (iq_valid_new)
    );   
    

    
    // ============================================================
    // 10. DE WACHTKAMER OPLOSSING (Perfecte I2S Frame Uitlijning)
    // ============================================================
    wire [31:0] I_filtered;
    wire [31:0] Q_filtered;
    wire        strobe_iq; 

    FIR_IQ filter_i (
        .clk_49152 (clk_49152),
        .reset     (i2s_reset),
        .sample_in (I_data),      
        .strobe_in (iq_valid_new),   
        .sample_out(I_filtered),
        .strobe_out(strobe_iq)    
    );

    FIR_IQ filter_q (
        .clk_49152 (clk_49152),
        .reset     (i2s_reset),
        .sample_in (Q_data),      
        .strobe_in (iq_valid_new),   
        .sample_out(Q_filtered),
        .strobe_out()             
    );  
    
      

    // Puls Oprekker 
    reg strobe_w2_delay;
    always @(posedge clk_49152) begin
        strobe_w2_delay <= strobe_w2;
    end
    
    wire safe_tx_strobe = strobe_w2 | strobe_w2_delay;  
    
    
    // ------------------------------------------------------------
    // 11. I2S uitgang
    // ------------------------------------------------------------           
    I2STX i2s_uitgang(
        .i2s_tx_bclk    (clk2_out1),              
        .reset          (i2s_reset),        
        .tx_in_left     (I_filtered), 
        .tx_in_right    (Q_filtered),         
        .tx_strobe      (safe_tx_strobe), 
		
        .i2s_tx_lrclk   (i2s_out_lrclk),
        .i2s_out_data   (i2s_out_data384)
    );      
    
    
    assign i2s_out_data384 = i2s_out_data384;
    assign i2s_out_lrclk384 = i2s_out_lrclk;  
    assign i2s_out_clk384 = clk2_out1;   

    //assign vcco_test_13_1 = 1'b1; // pin T9  

endmodule

